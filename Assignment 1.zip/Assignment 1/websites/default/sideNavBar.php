<!--This is to streamline code and reduce repetition--> 
<!--This is seperate to the other nav bar as not all pages require this side bar-->
<nav>
	<ul>
		<li><a href="adminArticles.php">Manage Articles</a></li>
		<li><a href="adminCategories.php">Manage Categories</a></li>
		<li><a href="manageAdmin.php">Manage Admins</a></li>
		<li><a href="logout.php">Log Out</a></li>
	</ul>
</nav>
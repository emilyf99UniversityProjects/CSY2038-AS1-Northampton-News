<!--Template file, used to make the footer and for the html layouts closing tags-->
</main>
		<footer>
			&copy; Northampton News 2021
		</footer>
	</body>
</html>

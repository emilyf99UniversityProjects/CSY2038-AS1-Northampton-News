<!-- Used to the index page-->
<!--This is in a seperate file to streamline other files -->
<nav>
    <ul>
        <li><a href="index.php">Go Back</a></li>
    </ul>
</nav>